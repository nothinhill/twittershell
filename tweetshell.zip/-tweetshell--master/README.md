# Tweetshell v1.1
Multi-thread Twitter BruteForcer in Shell Script

## Author: github.com/thelinuxchoice/tweetshell
## Twitter: @linux_choice

Tweetshell is an Shell Script to perform multi-threaded brute force attack against Twitter, this script can bypass login limiting and it can test infinite number of passwords with a rate of +400 passwords/min using 20 threads.

## Legal disclaimer:

Usage of TweetShell for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

![f1](https://user-images.githubusercontent.com/34893261/79010668-d038f480-7b38-11ea-8dde-509c5d0040c4.jpg)

### Features
- Multi-thread (400 pass/min, 20 threads)
- Save/Resume sessions
- Default password list (best +39k 8 letters)
- Check valid username

### Usage:
```
git clone https://github.com/thelinuxchoice/tweetshell
cd tweetshell
chmod +x tweetshell.sh
sudo ./tweetshell.sh
```

### Install requirements (Curl):

```
chmod +x install.sh
sudo ./install.sh
```
